const net = require('net');

const responses = {
    "CMD_SHIFT_INFO": {
        "id": "c45e2594-07a4-400d-9038-2457a3036c80",
        "command": "CMD_SHIFT_INFO",
        "result": "success",
        "data": {
            "shuftId": 1,
            "route": "111К",
            "tn": "123"
        },
        "mac": "xdolobsyyuoerdcyvwipuymcgrfnpkgs"
    },
    "CMD_CARD_READ": {
        "id": "c45e2594-07a4-400d-9038-2457a3036c80",
        "command": "CMD_CARD_READ",
        "result": "success",
        "data": {
            "date": 1730200400,
            "cardType": "transport",
            "cardNumber": "11111111",
            "cardSeries": 16,
            "cardPdType": "EP",
            "cardStatus": "active",
            "cardPassBalance": 3,
            "cardBalance": 14.50,
            "cardExpirationDate": 1730200400,
            "ticketExpirationDate": 1730200400,
            "whiteListSeries": 12,
            "firstname": "Иван",
            "secondname": "Иванов",
            "patronymic": "Иванович",
            "preferenceCode": "A",
            "cardNumberRL": "1234567890123456789"
        },
        "mac": "xdolobsyyuoerdcyvwipuymcgrfnpkgs"
    },
    "CMD_PASS_TRANSAPORT_CARD": {
        "id": "c45e2594-07a4-400d-9038-2457a3036c80",
        "command": "CMD_PASS_TRANSAPORT_CARD",
        "result": "success",
        "data": {
            "date": 1730200400,
            "cardNumber": "11111111",
            "cardSeries": 16,
            "cardPdType": "EP",
            "cardStatus": "active",
            "cardBalanceAfterPass": 14.3,
            "amountPass": 11.3
        },
        "mac": "xdolobsyyuoerdcyvwipuymcgrfnpkgs"
    },
    "CMD_PASS_BANK_CARD": {
        "id": "c45e2594-07a4-400d-9038-2457a3036c80",
        "command": "CMD_PASS_BANK_CARD",
        "result": "success",
        "data": {
            "date": 1730200400,
            "cardType": "bank",
            "cardNumber": "11111111",
            "cardSeries": 16,
            "cardPdType": "EP",
            "cardStatus": "active",
            "amountPass": 11.3
        },
        "mac": "xdolobsyyuoerdcyvwipuymcgrfnpkgs"
    },
    "CMD_ABORT": {
        "id": "c45e2594-07a4-400d-9038-2457a3036c80",
        "command": "CMD_ABORT",
        "result": "success",
        "mac": "xdolobsyyuoerdcyvwipuymcgrfnpkgs"
    }
};

const server = net.createServer((socket) => {
    console.log('Client connected');
    
    socket.on('data', (data) => {
        const request = JSON.parse(data);
        const response = responses[request.command];
        socket.write(JSON.stringify(response));
    });

    socket.on('end', () => {
        console.log('Client disconnected');
    });
});

server.listen(8080, () => {
    console.log('Server is listening on port 8080');
});