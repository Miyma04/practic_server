const net = require('net');
const readline = require('readline');

const client = new net.Socket();
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

client.connect(8080, '127.0.0.1', () => {
    console.log('Connected to server');
    askForCommand();
});

client.on('data', (data) => {
    console.log('Received from server:', data.toString());
});

client.on('close', () => {
    console.log('Connection closed');
});

function askForCommand() {
    rl.question('Enter command (CMD_SHIFT_INFO, CMD_CARD_READ, CMD_PASS_TRANSAPORT_CARD, CMD_PASS_BANK_CARD, CMD_ABORT): ', (command) => {
        let request;
        switch (command) {
            case 'CMD_SHIFT_INFO':
                request = JSON.stringify({
                    id: generateGUID(),
                    command: 'CMD_SHIFT_INFO'
                });
                break;
            case 'CMD_CARD_READ':
                request = JSON.stringify({
                    id: generateGUID(),
                    command: 'CMD_CARD_READ',
                    timeout: 15000
                });
                break;
            case 'CMD_PASS_TRANSAPORT_CARD':
                request = JSON.stringify({
                    id: generateGUID(),
                    command: 'CMD_PASS_TRANSAPORT_CARD',
                    timeout: 15000
                });
                break;
            case 'CMD_PASS_BANK_CARD':
                request = JSON.stringify({
                    id: generateGUID(),
                    command: 'CMD_PASS_BANK_CARD',
                    timeout: 15000
                });
                break;
            case 'CMD_ABORT':
                request = JSON.stringify({
                    id: generateGUID(),
                    command: 'CMD_ABORT'
                });
                break;
            default:
                console.log('Invalid command');
                askForCommand();
                return;
        }
        client.write(request);
        askForCommand();
    });
}

function generateGUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}